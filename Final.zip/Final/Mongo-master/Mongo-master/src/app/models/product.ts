export interface Product {
    _id: number;
    name: string;
    beforePrice: number;
    afterPrice: number;
    imgRef: string;
    quantity: number;
}
