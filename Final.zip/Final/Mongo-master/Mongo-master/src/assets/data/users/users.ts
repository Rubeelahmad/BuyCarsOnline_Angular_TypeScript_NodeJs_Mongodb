export let USERS = {
    users:
    
        {
            username: "Roei",
            password: "R123"
        }
    

}