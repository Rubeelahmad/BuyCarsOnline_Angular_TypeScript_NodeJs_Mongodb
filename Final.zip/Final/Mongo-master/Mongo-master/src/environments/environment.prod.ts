export const environment = {
    production: true,
    firebaseConfig: {
        apiKey: 'AIzaSyDhjhPJS9BL6x6Erckrg1xJ4l0bgCvsi-0',
        authDomain: 'qeni-ng.firebaseapp.com',
        projectId: 'qeni-ng',
        storageBucket: 'qeni-ng.appspot.com',
        messagingSenderId: '810478974552',
        appId: '1:810478974552:web:5d19ad5152605f1a9efc2d',
        measurementId: 'G-1YHE1TYGX1',
    },
};
