const Product = require("../models/ProductModel");
const { body,validationResult } = require("express-validator");
const { sanitizeBody } = require("express-validator");
const apiResponse = require("../helpers/apiResponse");
const auth = require("../middlewares/auth");
var mongoose = require("mongoose");
mongoose.set("useFindAndModify", false);
const { productService } = require('../services');
const catchAsync = require('../utils/catchAsync');

// Product Schema
function ProductData(data) {
	this.id = data._id;
	this.name= data.name;
	this.imgRef = data.imgRef;
	this.beforePrice = data.beforePrice;
    this.afterPrice = data.afterPrice;
    this.quantity = data.quantity
}




exports.createProduct = catchAsync(async (req, res) => {
  console.log(req.body);
  var product = new Product(
    { name: req.body.name,
        imgRef: req.body.imgRef,
        beforePrice: req.body.beforePrice,
        afterPrice: req.body.afterPrice,
        quantity: req.body.quantity
    });
  product=product.save(function(err){
      return apiResponse.ErrorResponse(res, err);
  });
  return apiResponse.successResponseWithData(res, "Operation success", product);

});

/**
 * Product List.
 * 
 * @returns {Object}
 */
exports.ProductList = [
	function (req, res) {
		try {
			Product.find({},"_id name imgRef beforePrice afterPrice quantity").then((Products)=>{
				if(Products.length > 0){
					return apiResponse.successResponseWithData(res, "Operation success", Products);
				}else{
					return apiResponse.successResponseWithData(res, "Operation success", []);
				}
			});
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
        }
	}
];

/**
 * Product Detail.
 * 
 * @param {string}      id
 * 
 * @returns {Object}
 */
exports.ProductDetail = [
	auth,
	function (req, res) {
		if(!mongoose.Types.ObjectId.isValid(req.params.id)){
			return apiResponse.successResponseWithData(res, "Operation success", {});
		}
		try {
			Product.findOne({_id: req.params.id},"_id name imgRef beforePrice afterPrice quantity").then((product)=>{                
				if(product !== null){
					let productData = new ProductData(product);
					return apiResponse.successResponseWithData(res, "Operation success", productData);
				}else{
					return apiResponse.successResponseWithData(res, "Operation success", {});
				}
			});
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];


/**
 * Product store.
 * 
 * @param {string}      name 
 * @param {string}      imgRef
 * @param {number}      beforePrice
 * @param {number}      afterPrice
 * @param {number}      quantity
 * 
 * @returns {Object}
 */
exports.ProductStore = [
	auth,
	body("name", "Name must not be empty.").isLength({ min: 1 }).trim(),
	body("imgRef", "ImgRef must not be empty.").isLength({ min: 1 }).trim().custom((value,{req}) => {
		return Product.findOne({id: req.body.id}).then(product => {
			if (product) {
				return Promise.reject("Product already exist with this id no.");
			}
		});
	}),
	body("*").escape(),
	(req, res) => {
        console.log(" req",req);
		try {
			const errors = validationResult(req);
			var product = new Product(
				{ name: req.body.name,
					imgRef: req.body.imgRef,
                    beforePrice: req.body.beforePrice,
                    afterPrice: req.body.afterPrice,
					quantity: req.body.quantity
				});

			if (!errors.isEmpty()) {
				return apiResponse.validationErrorWithData(res, "Validation Error.", errors.array());
			}
			else {
				//Save Product.
				product.save(function (err) {
					if (err) { return apiResponse.ErrorResponse(res, err); }
					let productData = new ProductData(product);
					return apiResponse.successResponseWithData(res,"Product add Success.", productData);
				});
			}
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Product update.
 * 
 * @param {string}      name 
 * @param {string}      imgRef
 * @param {number}      beforePrice
 * @param {number}      afterPrice
 * @param {number}      quantity
 * 
 * @returns {Object}
 */
exports.ProductUpdate = [
	auth,
	body("name", "Name must not be empty.").isLength({ min: 1 }).trim(),
	body("imgRef", "imgRef must not be empty.").isLength({ min: 1 }).trim().custom((value,{req}) => {
		return Product.findOne({_id: { "$ne": req.params.id }}).then(product => {
			if (product) {
				return Promise.reject("Product already exist with this id");
			}
		});
	}),
	body("*").escape(),
	(req, res) => {
		try {
			const errors = validationResult(req);
			var product = new Product(
				{ name: req.body.name,
					imgRef: req.body.imgRef,
                    beforePrice: req.body.beforePrice,
                    afterPrice: req.body.beforePrice,
                    quantity: req.body.quantity,
					_id:req.params.id
				});

			if (!errors.isEmpty()) {
				return apiResponse.validationErrorWithData(res, "Validation Error.", errors.array());
			}
			else {
				if(!mongoose.Types.ObjectId.isValid(req.params.id)){
					return apiResponse.validationErrorWithData(res, "Invalid Error.", "Invalid ID");
				}else{
					Product.findById(req.params.id, function (err, foundProduct) {
						if(foundProduct === null){
							return apiResponse.notFoundResponse(res,"Product not exists with this id");
						}else{

                            //update Product.
							Product.findByIdAndUpdate(req.params.id, product, {},function (err) {
								if (err) { 
									return apiResponse.ErrorResponse(res, err); 
								}else{
									let productData = new ProductData(product);
									return apiResponse.successResponseWithData(res,"Product update Success.", productData);
								}
							});
						}
					});
				}
			}
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

/**
 * Product Delete.
 * 
 * @param {string}      id
 * 
 * @returns {Object}
 */
exports.ProductDelete = [
	function (req, res) {
		if(!mongoose.Types.ObjectId.isValid(req.params.id)){
			return apiResponse.validationErrorWithData(res, "Invalid Error.", "Invalid ID");
		}
		try {
			Product.findById(req.params.id, function (err, foundProduct) {
				if(foundProduct === null){
					return apiResponse.notFoundResponse(res,"Product not exists with this id");
				}else{
                    //delete product.
						Product.findByIdAndRemove(req.params.id,function (err) {
							if (err) { 
								return apiResponse.ErrorResponse(res, err); 
							}else{
								return apiResponse.successResponse(res,"Product delete Success.");
							}
						});
				}
			});
		} catch (err) {
			//throw error in json response with status 500. 
			return apiResponse.ErrorResponse(res, err);
		}
	}
];

// module.exports = {
//     createProduct,
// };