const httpStatus = require('http-status');
const { Product } = require('../models');
const ApiError = require('../utils/ApiError');


const createProduct = async (productBody)=>{
    console.log(" This is Product");
    console.log(productBody);
    const product = await Product.create(productBody);
    return product;
}


module.exports = {
    createProduct,
};