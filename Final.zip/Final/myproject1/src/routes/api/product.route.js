var express = require("express");
const ProductController = require("../../controllers/product.controller");

var router = express.Router();

router.get("/list", ProductController.ProductList);
router.get("/:id", ProductController.ProductDetail);
router.post("/", ProductController.ProductStore);
router.post("/create", ProductController.createProduct);
router.put("/:id", ProductController.ProductUpdate);
router.delete("/:id", ProductController.ProductDelete);

module.exports = router;