var mongoose = require("mongoose");

var Schema = mongoose.Schema;

var ProductSchema = new Schema({
	name: {type: String, required: true},
	imgRef: {type: String, required: true},
    beforePrice: {type:Number, required: true},
    afterPrice: {type:Number, required: true},
    quantity: {type:Number, required: true},
}, {timestamps: true});

module.exports = mongoose.model("Product", ProductSchema);
